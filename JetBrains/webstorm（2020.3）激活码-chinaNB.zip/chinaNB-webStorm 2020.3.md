> 本文由 [简悦 SimpRead](http://ksria.com/simpread/) 转码， 原文地址 [www.jianshu.com](https://www.jianshu.com/p/28f4e9a6c7c8)

> *   直接上代码
> *   技术交流QQ群 `277030213`

### 1.下载

*   安装完成后，选择 ”Evaluate for free“ ，点击 “Evaluate” 进入 IDE 中，新建或打开一个项目。
    
      
    ![](//upload-images.jianshu.io/upload_images/1433350-5fc3b601fd6b04c6.png?imageMogr2/auto-orient/strip|imageView2/2/w/784/format/webp) image

> *   说明：如果不能出现这个界面，请打开压缩包执行相应的重置脚本~
> *   windows系统：reset_jetbrains_eval_windows.vbs
> *   linux/mac系统：reset_jetbrains_eval_mac_linux.sh

### 2.打开插件中心 File -> Settings -> Manage Plugins Reposito，设置插件中心仓库，如下图所示

![](//upload-images.jianshu.io/upload_images/1433350-12b44d55f9eeb5db.png?imageMogr2/auto-orient/strip|imageView2/2/w/985/format/webp) image

### 3.设置仓库地址：`https://repo.idechajian.com` ，如下图所示

![](//upload-images.jianshu.io/upload_images/1433350-df66994c3a647016.png?imageMogr2/auto-orient/strip|imageView2/2/w/584/format/webp) image

*   点击OK，便可以在xx中心，搜索关键字`BetterIntellij`，如下图所示  
    ![](//upload-images.jianshu.io/upload_images/1433350-eed4a08140ba1607.png?imageMogr2/auto-orient/strip|imageView2/2/w/983/format/webp) image

### 4.安装xx

*   点击安装或者更新，便会提示你，已自动配置好javaagent~
*   这时，必须要`重启IDEA`，才能生效

#### 5.打开xx界面 Help -> Register，选择添加xxx（见key.txt），如下图所示

![](//upload-images.jianshu.io/upload_images/1433350-3e1e267ae1af57e8.png?imageMogr2/auto-orient/strip|imageView2/2/w/789/format/webp) image

#### 6.成功 2100年

![](//upload-images.jianshu.io/upload_images/1433350-d0c3f3432516e1cc.png?imageMogr2/auto-orient/strip|imageView2/2/w/802/format/webp) image

#### 7.资源下载地址

地址1 [https://545c.com/file/18744103-477393550](https://links.jianshu.com/go?to=https%3A%2F%2F545c.com%2Ffile%2F18744103-477393550)  
备用地址 [https://www.90pan.com/b2215764](https://links.jianshu.com/go?to=https%3A%2F%2Fwww.90pan.com%2Fb2215764)

#### 8.请群主喝咖啡

![](//upload-images.jianshu.io/upload_images/1433350-f0f6222092080d8c?imageMogr2/auto-orient/strip|imageView2/2/w/1079/format/webp) image