> ![](
https://static.wixstatic.com/media/ac9085_c4b15fef823046918f6a6aa6a1f1d45e~mv2.png
)

**3、运行「PhpStorm」，在弹出激活窗口，选择「Evaluate for free」，然后点击「Evaluate」按钮：**

 .responsive { border-radius: 10px 10px 10px 10px; width: 90%; height: auto; } ![图片未载入，请重新刷新页面。 ](
https://static.wixstatic.com/media/ac9085_e990a12295214d198ff272e797b35af5~mv2.png
)

**4、将「jetbrains-agent.jar」文件直接拖动到软件欢迎窗口里：**

 .responsive { border-radius: 10px 10px 10px 10px; width: 90%; height: auto; } ![图片未载入，请重新刷新页面。 ](
https://static.wixstatic.com/media/ac9085_c5984f3bc14a438fb67f0f0a25522e70~mv2.png
)

**5、在弹出的窗口点击「Restart」：**

 .responsive { border-radius: 10px 10px 10px 10px; width: 90%; height: auto; } ![图片未载入，请重新刷新页面。 ](
https://static.wixstatic.com/media/ac9085_cd218efcd6be442e850df5460d75a62a~mv2.png
)

**6、这时程序会自动重启，会弹出「JetbrainsAgent 配置助手」窗口，在安装参数栏复制粘贴下面的安装参数，然后点击「为 PhpStorm 安装」， 再点击「是」，程序会再次重新启动：**

**复制下方的安装参数：已更新20201130**

KC4CPs/mH19e7ze1GXfrQH1uVsZ+i1bDpeffO9FzA7pligqeLiXrrrm+IQugrHMlTOo3VZRzlhXOWCtetc6N0Q2n3BONIBwZP/1AJqid6e3pcqbVl7PLzMpWfTsWPcE8JkXhlopYgIADMSTwkm2MwMkPCkBiHAXAfJxwzoOgmIE

 .responsive { border-radius: 10px 10px 10px 10px; width: 90%; height: auto; } ![图片未载入，请重新刷新页面。 ](
https://static.wixstatic.com/media/ac9085_cfccfc14b8e441628e4393d3952a3335~mv2.png
)

**7、查看关于界面中显示下方信息说明已经激活成功！：）**

 .responsive { border-radius: 10px 10px 10px 10px; width: 90%; height: auto; } ![图片未载入，请重新刷新页面。 ](
https://static.wixstatic.com/media/ac9085_de65d229df684e8aa29cf5daf0278070~mv2.png
)

**8、为了防止自动更新，激活失效的问题，请按下图标识进行更新关闭：**

 .responsive { border-radius: 10px 10px 10px 10px; width: 90%; height: auto; } ![图片未载入，请重新刷新页面。 ](
https://static.wixstatic.com/media/ac9085_68e964bafefe410789d53f091cb5f10c~mv2.png
)

单击软件菜单栏下的「Preferences…」

 .responsive { border-radius: 10px 10px 10px 10px; width: 90%; height: auto; } ![图片未载入，请重新刷新页面。 ](
https://static.wixstatic.com/media/ac9085_6c6ba77cadc44ab9807b34ca509e1c2e~mv2.png
)

在搜索框处输入「update」

 .responsive { border-radius: 10px 10px 10px 10px; width: 90%; height: auto; } ![图片未载入，请重新刷新页面。 ](
https://static.wixstatic.com/media/ac9085_fc0f43e061da4651a6b13bdd20cd597d~mv2.png
)

把右侧的「Automatically check updates」取消勾选，然后点击「OK」

**二：汉化设置方法**

**1、点击菜单栏的「PhpStorm」，再点击「Preferences…」打开软件的偏好设置，点击左侧导航的「Plugins」，在右侧的「Type / to see options」处输入「chinese」,找到「Chinese ​(Simplified)​ Language」点击「Install」,安装完成后点击「Restart IDE」即可：**

 .responsive { border-radius: 10px 10px 10px 10px; width: 90%; height: auto; } ![图片未载入，请重新刷新页面。 ](
https://static.wixstatic.com/media/ac9085_7498b2f5c16840ac83ac7dca0527a87c~mv2.png
)  .responsive { border-radius: 10px 10px 10px 10px; width: 90%; height: auto; } ![图片未载入，请重新刷新页面。 ](
https://static.wixstatic.com/media/ac9085_a26f1be5c9a644f6b7354be41dd3c662~mv2.png
)

**三：付费插件说明**

**以下提供的插件激活码是针对使用Activation code激活的用户，在使用付费插件需要输入激活码！**

**[点这里下载插件激活码](https://uploads.strikinglycdn.com/files/5ee1e3a5-7b59-4ff7-9052-508c98f36031/插件 Activation code 激活码.zip)**

**激活码支持的付费插件列表：**

[JetForcer | The Smartest Force.com IDE](https://plugins.jetbrains.com/plugin/9238-jetforcer--the-smartest-force-com-ide/)

[Java Antidecompiler](https://plugins.jetbrains.com/plugin/11560-java-antidecompiler/)

[OpenAPI Editor](https://plugins.jetbrains.com/plugin/12887-openapi-editor/)

[CMake Plus](https://plugins.jetbrains.com/plugin/12869-cmake-plus/)

[ZenUML support](https://plugins.jetbrains.com/plugin/12437-zenuml-support/)

[Markdown Navigator Enhanced](https://plugins.jetbrains.com/plugin/7896-markdown-navigator-enhanced/)

[AEM Support](https://plugins.jetbrains.com/plugin/9863-aem-support/)

[JavaDoc Clean Read](https://plugins.jetbrains.com/plugin/10828-javadoc-clean-read/)

[Manifold](https://plugins.jetbrains.com/plugin/10057-manifold/)

[Shopware](https://plugins.jetbrains.com/plugin/7410-shopware/)

[OrchidE](https://plugins.jetbrains.com/plugin/12626-orchide/)

[POJO to JSON Schema](https://plugins.jetbrains.com/plugin/13733-pojo-to-json-schema/)

[Laravel Idea](https://plugins.jetbrains.com/plugin/13441-laravel-idea/)

[Code Review for Bitbucket](https://plugins.jetbrains.com/plugin/13538-code-review-for-bitbucket/)

[JFormDesigner (Marketplace Edition)](https://plugins.jetbrains.com/plugin/12621-jformdesigner-marketplace-edition-/)

[hybris integration](https://plugins.jetbrains.com/plugin/7525-hybris-integration/)

[MinBatis](https://plugins.jetbrains.com/plugin/13720-minbatis/)

[Scipio ERP Integration](https://plugins.jetbrains.com/plugin/12108-scipio-erp-integration/)

[Meson Syntax Highlighter](https://plugins.jetbrains.com/plugin/13269-meson-syntax-highlighter/)

[MyBatis Log Plugin](https://plugins.jetbrains.com/plugin/13905-mybatis-log-plugin/)

[Wolfram Language](https://plugins.jetbrains.com/plugin/7232-wolfram-language/)

[SystemVerilog](https://plugins.jetbrains.com/plugin/10695-systemverilog/)

[Generate Document](https://plugins.jetbrains.com/plugin/13086-generate-document/)

[RON (Rusty Object Notation)](https://plugins.jetbrains.com/plugin/12635-ron-rusty-object-notation-/)

[Iceberg](https://plugins.jetbrains.com/plugin/12984-iceberg/)

[Smart Jump](https://plugins.jetbrains.com/plugin/14053-smart-jump/)

[Merge Request Integration EE - Code Review for GitLab](https://plugins.jetbrains.com/plugin/13615-merge-request-integration-ee--code-review-for-gitlab/)

[Iedis 2](https://plugins.jetbrains.com/plugin/12634-iedis-2/)

[BashSupport Pro](https://plugins.jetbrains.com/plugin/13841-bashsupport-pro/)

[OfficeFloor](https://plugins.jetbrains.com/plugin/13151-officefloor/)

[Salesforce B2C Commerce (SFCC)](https://plugins.jetbrains.com/plugin/13668-salesforce-b2c-commerce-sfcc-/)

[RDF and SPARQL](https://plugins.jetbrains.com/plugin/13838-rdf-and-sparql/)

[Cypress-Pro](https://plugins.jetbrains.com/plugin/13987-cypress-pro/)

[AutoCode for Java](https://plugins.jetbrains.com/plugin/10904-autocode-for-java/)